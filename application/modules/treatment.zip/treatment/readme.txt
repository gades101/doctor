version 0.0.2
Requires Chikitsa 0.2.1
Compatible upto 0.2.1

0.0.3
1. Compatible with 0.2.4
0.0.2
1. Compatible with 0.2.1
0.0.1
1. Maintain list of treatments with its price list
2. Add treatments in Bill and Visit
