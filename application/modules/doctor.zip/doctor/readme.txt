version 0.0.4
Requires Chikitsa 0.2.4

0.0.1
1. Create Different Departments
2. Allocate Doctors in different departments
3. Maintain Doctor�s Profile
4. Maintain Doctor�s Fees
5. Maintain Individual Schedule for each Doctor
6. Maintain Doctor�s Inavailability

0.0.2
1. The Features were not visible in Doctor�s Login. Corrected this.

0.0.3
1. Bug Fix for Doctor Schedule

0.0.4
1. Compatible with v0.2.4
 